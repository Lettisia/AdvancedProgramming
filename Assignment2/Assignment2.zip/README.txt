Advanced Programming Assignment 2

Lettisia George - s3671532
Theo Dufort - s3593458

To Run:
Open a command prompt, navigate to the folder containing 
 - Ozlympics.jar
 - sqlite-jdbc-3.16.1.jar
 - test.db 
 - participants.txt

Type Ozlympics.jar to run the game.

Source code is under src folder.